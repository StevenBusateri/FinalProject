package com.example.hw7;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "CalculateBill")
public class CalculateBill extends HttpServlet {

    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response) throws ServletException, IOException {

        ArrayList<Double> price;
      if(  Database.init()) {

     price  = Database.getItemsFromDatabase();
      }else {
          price = new ArrayList<Double>();
          price.add(1.0);
          price.add(5.0);
          price.add(2.0);

      }
        // read form fields

        int cheese = Integer.parseInt(request.getParameter("Cheeseburger"));
        int nachos = Integer.parseInt(request.getParameter("Nachos"));
        int pizza = Integer.parseInt(request.getParameter("Pepperoni Pizza"));

        // do some processing here...

        // get response writer
        PrintWriter writer = response.getWriter();

        // build HTML code
        String htmlRespone = "<html>";


        if (price != null){

            double cheesePrice = price.get(0) * cheese;

            double nachoPrice = price.get(1) *nachos;
            double pizzaPrice = price.get(2) * pizza;

            htmlRespone += "Cheeseburger: " + cheese + "(" + cheesePrice  + ")\n";
            htmlRespone += "<br>";
        htmlRespone += "Nachos: " + nachos + "(" + nachoPrice + ")\n";
            htmlRespone += "<br>";

            htmlRespone += "Pizza: " + pizza + "(" + pizzaPrice + ")\n";
            htmlRespone += "<br>";

        htmlRespone += "Total: " + "$" + (nachoPrice + pizzaPrice +cheesePrice);
    }
        else{

            htmlRespone += "Not connected to database: " ;

        }

        htmlRespone += "</html>";

        // return response
        writer.println(htmlRespone);

    }

}
class Database {


    public static boolean isConnected = false;
    private static final String HOST = "localhost";
    private static Statement stmt;


    public Database() {

    }

    public static boolean init() {

        System.out.println("Attempting connection");
        if(isConnected)
            return true;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded");
            Connection connection = DriverManager.getConnection
                    ("jdbc:mysql://" + HOST + "/restaurant", "root", "root");
            System.out.println("Database connected");
            isConnected = true;
            stmt = connection.createStatement();

        } catch (Exception e) {
            System.err.println("Database failed to connect ");
e.printStackTrace();
            return  false;

        }

        return isConnected;
    }


    public static void registerOrderOnDatabase(int q1, int q2, int q3, int q4) {

        System.out.println("Registering order...");
        try {
            String queryString = "INSERT INTO `restaurant`.`orders` ( `item1_qty`, `item2_qty`, `item3_qty`,`item4_qty`) VALUES ('" + q1 + "', '" + q2 + "', '" + q3 + "', '" + q4 + "');";
            stmt.executeUpdate(queryString);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Double> getItemsFromDatabase() {
        if (!isConnected) {
            System.out.println("Not connected to " + HOST);
            return null;
        }
        ArrayList<Double> items = new ArrayList<Double>();
        try {

            String queryString = "SELECT * FROM restaurant.menu";

            ResultSet rset = stmt.executeQuery(queryString);

            while (rset.next()) {
                String id = rset.getString(1);
                String name = rset.getString(2);
                String price = rset.getString(3);


                items.add(Double.parseDouble(price));


            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return items;
    }


}
