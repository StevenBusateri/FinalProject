import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;

public class Hw2 extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        boolean databaseLoaded = Database.init();
        if (databaseLoaded)
            new OrderStage();
        else {
            System.err.println("Database not set up");
        }

    }


    public static void main(String[] args) {
        launch();


    }
}


class OrderStage extends Stage {

    public OrderStage() {
        LocalDate date = LocalDate.now();
        DayOfWeek day = date.getDayOfWeek();
        ArrayList<Item> items = Database.getItemsFromDatabase();
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(0, 0, 0, 0));
//pane.setGridLinesVisible(true);
        Text titleLabel = new Text("Julien's Restaurant");
        titleLabel.setFont(new Font(20));
        pane.add(titleLabel, 2, 0);
//
//        Item dailyDeal = getDailyDeal(day);
//        Item item1 = new Item("Fries", "/images/fries.jfif", 2.00);
//        Item item2 = new Item("Turkey", "/images/chickenjfif.jfif", 3.00);
//        Item item3 = new Item("Orange", "/images/orangejfif.jfif", 2.00);

        TextField dailyDealText = addItem(items.get(0), 1, pane);
        TextField i1DealText = addItem(items.get(1), 2, pane);
        TextField i2DealText = addItem(items.get(2), 3, pane);
        TextField i3DealText = addItem(items.get(3), 4, pane);

        Button orderButton = new Button("Order");
        orderButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {

                if (dailyDealText.getText().isEmpty()) {
                    dailyDealText.setText("0");
                }
                if (i1DealText.getText().isEmpty()) {
                    i1DealText.setText("0");
                }
                if (i2DealText.getText().isEmpty()) {
                    i2DealText.setText("0");
                }
                if (i3DealText.getText().isEmpty()) {
                    i3DealText.setText("0");
                }
                items.get(0).setQuantity(Integer.parseInt(dailyDealText.getText()));
                items.get(1).setQuantity(Integer.parseInt(i1DealText.getText()));
                items.get(2).setQuantity(Integer.parseInt(i2DealText.getText()));
                items.get(3).setQuantity(Integer.parseInt(i3DealText.getText()));
                new DisplayStage(new Item[]{items.get(0), items.get(1), items.get(2), items.get(3)});
            }
        });
        pane.add(orderButton, 5, 5);


        Scene scene = new Scene(pane, 800, 900);
        setTitle("Order Screen - Day of Week: " + day);
        setScene(scene);
        show();

    }


    public TextField addItem(Item i, int level, GridPane pane) {
        ImageView itemDealImage = new ImageView(i.getPath());
        itemDealImage.setScaleY(0.5);
        itemDealImage.setScaleX(0.5);
        Text itemDealText = new Text(i.getName() + ": " + i.getPrice());
        itemDealText.setFont(new Font(15));
        TextField itemTextField = new TextField();
        itemTextField.setEditable(true);
        itemTextField.setPrefWidth(50);
        pane.add(itemDealImage, 1, level);
        pane.add(itemDealText, 2, level);
        pane.add(itemTextField, 3, level);
        return itemTextField;
    }

}

class DisplayStage extends Stage {
    DisplayStage(Item[] items) {

        Database.registerOrderOnDatabase(items[0].getQuantity(), items[1].getQuantity(), items[2].getQuantity(), items[3].getQuantity());
        GridPane box = new GridPane();
        Text text = new Text();
        String t = "";
        double total = 0;
        for (Item i :
                items) {
            if (i.getQuantity() > 0) {
                t += i + "\n";
                total += i.getTotal();
            }
        }
        text.setText(t);
        Text totalText = new Text("Total: $" + String.format("%.2f", total));
        box.add(text, 0, 0);
        box.add(totalText, 0, 5);
        totalText.setFont(Font.font("verdana", FontWeight.BOLD, 20));

        Scene scene = new Scene(box, 800, 900);
        setTitle("Display Screen");
        setScene(scene);
        show();

    }
}

class Database {


    public static boolean isConnected = false;
    private static final String HOST = "localhost";
    private static Statement stmt;


    public Database() {

    }

    public static boolean init() {
        if(isConnected)
            return true;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded");
            Connection connection = DriverManager.getConnection
                    ("jdbc:mysql://" + HOST + "/restaurant", "root", "root");
            System.out.println("Database connected");
            isConnected = true;
            stmt = connection.createStatement();

        } catch (Exception e) {
        }

        return isConnected;
    }


    public static void registerOrderOnDatabase(int q1, int q2, int q3, int q4) {

        System.out.println("Registering order...");
        try {
            String queryString = "INSERT INTO `restaurant`.`orders` ( `item1_qty`, `item2_qty`, `item3_qty`,`item4_qty`) VALUES ('" + q1 + "', '" + q2 + "', '" + q3 + "', '" + q4 + "');";
             stmt.executeUpdate(queryString);
        } catch (Exception e) {
        e.printStackTrace();
        }
    }

    public static ArrayList<Item> getItemsFromDatabase() {
        if (!isConnected) {
            System.out.println("Not connected to " + HOST);
        }
        ArrayList<Item> items = new ArrayList<Item>();
        try {

            String queryString = "SELECT * FROM restaurant.menu";

            ResultSet rset = stmt.executeQuery(queryString);

            while (rset.next()) {
                String id = rset.getString(1);
                String name = rset.getString(2);
                String price = rset.getString(3);


                items.add(new Item(Integer.parseInt(id), name, Double.parseDouble(price)));


            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return items;
    }


}

class Item {

    private String name, path;
    private String[] imgPaths = {"fried.jfif", "fries.jfif", "chickenjfif.jfif", "orangejfif.jfif"};

    private double price;
    private int quantity;

    public Item(int id, String name, double price) {
        this.name = name;
        this.price = price;
        this.path = "images/" + imgPaths[id - 1];
    }


    public void setQuantity(int i) {
        quantity = i;

    }

    public int getQuantity() {
        return quantity;
    }

    public double getTotal() {
        return quantity * price;
    }

    public String getName() {
        return name;
    }


    public String getPath() {
        return path;
    }


    public String getPrice() {
        return "$" + String.format("%.2f", price);
    }

    public String toString() {
        return quantity + " " + name;
    }
}